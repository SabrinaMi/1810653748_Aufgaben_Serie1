package Package2;

public class NeueKlasse
{
    public static void main(String[] args)
    {
        System.out.println("FH Kufstein Tirol");
    }
}
